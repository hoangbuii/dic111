/**
 * A factory for creating PC instances.
 */
public class PCFactory {
    private static PCFactory instance;

    private PCFactory() {
    }

    /**
     * Gets the singleton instance of the PCFactory.
     *
     * @return The singleton instance of the PCFactory.
     */
    public static synchronized PCFactory getInstance() {
        if (instance == null) {
            instance = new PCFactory();
        }
        return instance;
    }

    /**
     * Creates a new PC object.
     *
     * @param model        The model of the PC.
     * @param year         The manufacturing year of the PC.
     * @param manufacturer The manufacturer of the PC.
     * @param comps        The set of components of the PC.
     * @return A new PC object.
     */
    public PC createPC(String model, int year, String manufacturer, Set<String> comps) {
        return new PC(model, year, manufacturer, comps);
    }
}
