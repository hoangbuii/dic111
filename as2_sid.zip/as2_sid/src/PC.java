// PC.java


/**
 * Represents a Personal Computer (PC).
 */
public class PC {
    private String model;
    private int year;
    private String manufacturer;
    private Set<String> comps;

    /**
     * Constructs a PC object.
     *
     * @param model        The model of the PC.
     * @param year         The manufacturing year of the PC.
     * @param manufacturer The manufacturer of the PC.
     * @param comps        The components of the PC.
     */
    public PC(String model, int year, String manufacturer, Set<String> comps) {
        this.model = model;
        this.year = year;
        this.manufacturer = manufacturer;
        this.comps = comps;
    }

    // Getters and setters

    /**
     * Gets the model of the PC.
     *
     * @return The model of the PC.
     */
    public String getModel() {
        return model;
    }

    /**
     * Sets the model of the PC.
     *
     * @param model The model of the PC.
     */
    public void setModel(String model) {
        this.model = model;
    }

    /**
     * Gets the manufacturing year of the PC.
     *
     * @return The manufacturing year of the PC.
     */
    public int getYear() {
        return year;
    }

    /**
     * Sets the manufacturing year of the PC.
     *
     * @param year The manufacturing year of the PC.
     */
    public void setYear(int year) {
        this.year = year;
    }

    /**
     * Gets the manufacturer of the PC.
     *
     * @return The manufacturer of the PC.
     */
    public String getManufacturer() {
        return manufacturer;
    }

    /**
     * Sets the manufacturer of the PC.
     *
     * @param manufacturer The manufacturer of the PC.
     */
    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    /**
     * Gets the components of the PC.
     *
     * @return The components of the PC.
     */
    public Set<String> getComps() {
        return comps;
    }

    /**
     * Sets the components of the PC.
     *
     * @param comps The components of the PC.
     */

    public void setComps(Set<String> comps) {
        this.comps = comps;
    }

    @Override
    public String toString() {
        return "PC<" + model + ", " + year + ", " + manufacturer + ", " + comps + ">";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof PC)) {
            return false;
        }
        PC other = (PC) obj;
        return this.model.equals(other.model) &&
                this.year == other.year &&
                this.manufacturer.equals(other.manufacturer) &&
                this.comps.equals(other.comps);
    }
}
