public class PCReport {
    /**
     *
     * @param objs
     * @return
     */
    public String displayReport(PC[] objs) {
        String report = "----------------------------------------------------------------" +
                "-----------------------------------\n                                   " +
                "        PCPROG REPORT\n-------------------------------------------------" +
                "--------------------------------------------------\n";
        for (int i = 0; i < objs.length; i++) {
            String components = objs[i].getComps().getElements().toString();
            if (components.length() > 51) {
                components = components.substring(0, 46);
                components += " ...]";
            }
            report += String.format("%3s %20s %6s %15s %-51s\n", i + 1, objs[i].getModel(),
                    objs[i].getYear(), objs[i].getManufacturer(), components);
        }
        report += "----------------------------------------------------------------------" +
                "-----------------------------";
        return report;
    }
}
